﻿<?php
include_once 'includes/header.php';
include_once 'includes/sidebar.php';
?>
<div class="grid_10">

  <div class="box round first grid">
    <h2> Dashbord</h2>
    <div class="block">
      Bonjour Administrateur
    </div>
  </div>
</div>

<?php
include_once 'includes/footer.php';
?>