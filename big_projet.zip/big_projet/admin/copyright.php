﻿<?php
// Inclure le fichier header.php
include_once "includes/header.php";
// Inclure le fichier sidebar.php
include_once "includes/sidebar.php";
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Mettre à jour le texte du droit d'auteur</h2>
        <!--   For update copyright media -->
        <?php

        
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            $copyright = $title = mysqli_real_escape_string($db->link,$_POST['copyright']);
            
            if(empty($copyright)){
                echo "Il n'y a pas de copyright";
            }
            else {
                $copyright_get = "UPDATE footer SET copyright='$copyright'";
                $copyright_update = $db->update($copyright_get);
                if($copyright_update){
                    echo "Copyright mis à jour";
                }else{
                    echo "Erreur";
                }
            }
    }
        ?>

        <div class="block copyblock">
            
            <?php
            $query = "SELECT * FROM footer";
            $copyright_query= $db->select($query);
            if($copyright_query){
                while($result=$copyright_query->fetch_assoc()){
                    $query="SELECT * FROM footer";
                    echo $result['copyright'];
                }}
            ?>
            <form action="" method="post">
                <table class="form">
                    <tr>
                        <td>
                            <input type="text" value="" name="copyright" class="large" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <input type="submit" name="submit" Value="Modifier" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php
// Inclure le fichier footer.php
include_once "includes/footer.php";
?>