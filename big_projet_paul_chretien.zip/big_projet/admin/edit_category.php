<?php
 ob_start();

include_once "includes/header.php";

include_once "includes/sidebar.php";
?>
<?php


if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $catid = $_GET['catid'];
    
}

if (!isset($_GET['catid']) || $_GET['catid'] == NULL ){
header('location:category_list.php');
}else{
    $id = $_GET['catid'];
    
}

?>


<div class="grid_10">

    <div class="box round first grid">
        <h2>Update Category</h2>
        <div class="block copyblock">
            <?php

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $name = $_POST['name'];
                $name = mysqli_real_escape_string($db->link, $name);
                if(empty($name)){
                    echo 'error';
                }else{
                    
                    $query = "UPDATE category SET name='$name' WHERE category_id=$id";
                    $update_cat =  $db->update($query);
                    if ($update_cat) {
                        echo "<span style='color:green;font-size:18px;'>Catégorie modifier avec succès</span>";
                    } else {
                        echo "<span style='color:red;font-size:18px;'>Catégorie non modifier</span>";
                    }
                }
                
            }
            ?>
            <form method="post">
                <table class="form">
                    <tr>
                        <td>
                            <input type="text" name="name" value="" class="medium" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="submit" name="submit" Value="Modifier" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php
// Inclure le fichier footer.php
include_once 'includes/footer.php';
ob_end_flush();
?>