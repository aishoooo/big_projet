﻿<?php
include_once "includes/header.php";
include_once "includes/sidebar.php";
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Category List</h2>
        <?php

        if(isset($_GET['delid'])){
        
            $delid = $_GET['delid'];
            $delid_query = "DELETE FROM category WHERE category_id = '$delid'";
            $delete_data = $bd->delete($delid_query);
            if($delete_data){
                echo "Cette table n'existe plus";
            }else{
                echo "Table non supprimé";
            }
        }
        ?>
        <div class="block">
            <table class="data display datatable" id="example">
                <thead>
                    <tr>
                        <th>N. De série</th>
                        <th>Nom Catégorie</th>
                        <th>Action</th>
                    </tr>
                </thead>
<tbody>
                <?php
                    $query="SELECT * FROM category";
                    $category= $db->select($query);
                  
                if ($category){
                    while ($result=$category->fetch_assoc()){
                        $query="SELECT * FROM category";


                ?>
                    <tr class="odd gradeX">
                        <td><?=$result['category_id']?></td>
                        <td><?=$result['name']?></td>
                        <td><a href="edit_category.php?catid=<?php echo $result['category_id']; ?>">Modifier</a>
                            || <a onclick="return confirm('Êtes-vous sûr de vouloir supprimer?')" href="delete_category.php?catid=<?php echo $result['category_id']; ?>">Supprimer</a></td>
                    </tr>
                    <?php }
                   } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();


    });
</script>

<?php
include_once 'includes/footer.php'
?> 