<?php
ob_start();
include_once "includes/header.php";
include_once "includes/sidebar.php";
?>
<?php
$id = $_GET['catid'];
$query = "DELETE FROM category WHERE category_id=$id";
$delete_cat =  $db->delete($query);

?>
<?php

include_once 'includes/footer.php';
header('location:category_list.php');
ob_end_flush()
?>