    <?php include_once "../classes/Session.php";
    Session::checkSession();
    ?>
    <?php include_once "../config/config.php" ?>
    <?php include_once "../db/Database.php" ?>
    <?php include_once "../classes/format.php" ?>

    <?php
    $db = new Database();
    $format = new Format();

    ?>
    <!DOCTYPE html>
    <html lang="fr">

        <head>
            <meta http-equiv="content-type" content="text/php; charset=utf-8" />
            <title> Admin</title>
            <link rel="stylesheet" type="text/css" href="css/reset.css" media="screen" />
            <link rel="stylesheet" type="text/css" href="css/text.css" media="screen" />
            <link rel="stylesheet" type="text/css" href="css/grid.css" media="screen" />
            <link rel="stylesheet" type="text/css" href="css/layout.css" media="screen" />
            <link rel="stylesheet" type="text/css" href="css/nav.css" media="screen" />
            <link href="css/table/demo_page.css" rel="stylesheet" type="text/css" />
            <!-- BEGIN: load jquery -->
            <script src="js/jquery-1.6.4.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="js/jquery-ui/jquery.ui.core.min.js"></script>
            <script src="js/jquery-ui/jquery.ui.widget.min.js" type="text/javascript"></script>
            <script src="js/jquery-ui/jquery.ui.accordion.min.js" type="text/javascript"></script>
            <script src="js/jquery-ui/jquery.effects.core.min.js" type="text/javascript"></script>
            <script src="js/jquery-ui/jquery.effects.slide.min.js" type="text/javascript"></script>
            <script src="js/jquery-ui/jquery.ui.mouse.min.js" type="text/javascript"></script>
            <script src="js/jquery-ui/jquery.ui.sortable.min.js" type="text/javascript"></script>
            <script src="js/table/jquery.dataTables.min.js" type="text/javascript"></script>
            <!-- END: load jquery -->
            <script type="text/javascript" src="js/table/table.js"></script>
            <script src="js/setup.js" type="text/javascript"></script>
            <script type="text/javascript">
                $(document).ready(function() {
                    setupLeftMenu();
                    setSidebarHeight();
                });
            </script>

        </head>

        <body>
            <div class="container_12">
                <div class="grid_12 header-repeat">
                    <div id="branding">
                        <?php
                        $query = "SELECT * FROM title WHERE id='1'";
                        $title = $db->select($query);
                        if ($title) {
                            while ($result = $title->fetch_assoc()) {

                        ?>
                                <div class="floatleft middle">
                                    <h1>Portfolio</h1>
                                    <p>Administrateur</p>
                                </div>
                        <?php }
                        } ?>
                        <div class="floatright">
                            <div class="floatleft">
                                <img src="img/img-profile.jpg" alt="Profile Pic" />
                            </div>
                            <div class="floatleft marginleft10">
                                <?php
                                if (isset($_GET['action']) && $_GET['action'] == 'logout') {
                                    Session::destroy();
                                }
                                ?>
                                <ul class="inline-ul floatleft">
                                    <li>Admin</li>
                                    <li><a href="?action=logout">Déconnexion</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="clear">
                        </div>
                    </div>
                </div>
                <div class="clear">
                </div>
                <div class="grid_12">
                    <ul class="nav main">
                        <li class="ic-dashboard">
                            <a href="index.php"><span>Tableau de bord</span></a>
                        </li>
                        <li class="ic-charts">
                            <a target="_blank" href="../index.php"><span>Visiter le site</span></a>
                        </li>
                    </ul>
                </div>
                <div class="clear">
            </div>
        </body>
    </html>