<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <li><a class="menuitem">Configuration</a>
                    <ul class="submenu">
                        <li><a href="copyright.php">Copyright</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">Option Catégories</a>
                    <ul class="submenu">
                        <li><a href="add_category.php">Ajouter une catégorie</a> </li>
                        <li><a href="category_list.php">Liste des catégories</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Option Posts</a>
                    <ul class="submenu">
                        <li><a href="add_post.php">Ajouter un posts</a> </li>
                        <li><a href="post_list.php">Liste des posts</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>