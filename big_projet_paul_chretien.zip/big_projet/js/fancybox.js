<script>
$(document).ready(function() {
  $(".fancybox").fancybox({
    buttons: [
      "zoom",
      "fullScreen",
      "close"
    ],
    animationEffect: "zoom-in-out"
  })
});
</script>